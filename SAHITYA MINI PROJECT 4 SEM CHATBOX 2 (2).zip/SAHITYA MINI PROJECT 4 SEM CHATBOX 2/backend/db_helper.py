import sqlite3
from pathlib import Path

# Define the SQLite database file
db_path = Path("pandeyji_eatery.db")

# Connect to the SQLite database (it will be created if it doesn't exist)
connection = sqlite3.connect(db_path)

# Initialize the database schema
def initialize_database():
    cursor = connection.cursor()

    # Create `food_items` table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS food_items (
            item_id INTEGER PRIMARY KEY,
            name TEXT,
            price REAL
        );
    """)

    # Create `order_tracking` table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS order_tracking (
            order_id INTEGER PRIMARY KEY,
            status TEXT
        );
    """)

    # Create `orders` table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id INTEGER,
            item_id INTEGER,
            quantity INTEGER,
            total_price REAL,
            PRIMARY KEY (order_id, item_id),
            FOREIGN KEY (item_id) REFERENCES food_items(item_id)
        );
    """)

    # Insert sample data into `food_items`
    sample_food_items = [
        (1, 'Pav Bhaji', 6.00),
        (2, 'Chole Bhature', 7.00),
        (3, 'Pizza', 8.00),
        (4, 'Mango Lassi', 5.00),
        (5, 'Masala Dosa', 6.00),
        (6, 'Vegetable Biryani', 9.00),
        (7, 'Vada Pav', 4.00),
        (8, 'Rava Dosa', 7.00),
        (9, 'Samosa', 5.00),
    ]
    cursor.executemany("INSERT OR IGNORE INTO food_items VALUES (?, ?, ?);", sample_food_items)

    connection.commit()
    cursor.close()

# Example: Insert or update order items
def insert_or_update_order_item(food_item, quantity, order_id):
    cursor = connection.cursor()

    # Get the item_id and price for the food item
    cursor.execute("SELECT item_id, price FROM food_items WHERE name = ?;", (food_item,))
    result = cursor.fetchone()

    if not result:
        print(f"Food item '{food_item}' not found.")
        return

    item_id, price = result

    # Calculate total price
    total_price = price * quantity

    # Check if the item already exists in the order
    cursor.execute("""
        SELECT quantity FROM orders WHERE order_id = ? AND item_id = ?;
    """, (order_id, item_id))

    existing_item = cursor.fetchone()

    if existing_item:
        # Item exists, update quantity and total price
        new_quantity = existing_item[0] + quantity
        cursor.execute("""
            UPDATE orders 
            SET quantity = ?, total_price = ? 
            WHERE order_id = ? AND item_id = ?;
        """, (new_quantity, price * new_quantity, order_id, item_id))
        print(f"Order item '{food_item}' updated successfully!")
    else:
        # Item doesn't exist, insert a new record
        cursor.execute("""
            INSERT INTO orders (order_id, item_id, quantity, total_price)
            VALUES (?, ?, ?, ?);
        """, (order_id, item_id, quantity, total_price))
        print(f"Order item '{food_item}' added successfully!")

    connection.commit()
    cursor.close()

# Example: Get total order price
def get_total_order_price(order_id):
    cursor = connection.cursor()

    cursor.execute("""
        SELECT SUM(total_price) 
        FROM orders 
        WHERE order_id = ?;
    """, (order_id,))
    total_price = cursor.fetchone()[0] or 0

    cursor.close()
    return total_price

# Initialize the database
initialize_database()

# Example usage
if __name__ == "__main__":
    # Insert or update order items
    insert_or_update_order_item('Samosa', 3, 99)
    insert_or_update_order_item('Pizza', 2, 99)

    # Fetch total price for order
    total_price = get_total_order_price(99)
    print(f"Total Price for Order ID 99: {total_price}")

# Close the database connection
connection.close()
